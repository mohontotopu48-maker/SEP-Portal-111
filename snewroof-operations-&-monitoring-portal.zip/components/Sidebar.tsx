
import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  role: UserRole;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, role }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line', roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.ANALYST] },
    { id: 'costs', label: 'Billing & Costs', icon: 'fa-dollar-sign', roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.ANALYST] },
    { id: 'tools', label: 'Tools & Assets', icon: 'fa-toolbox', roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.ANALYST] },
    { id: 'monitoring', label: 'Uptime Monitor', icon: 'fa-server', roles: [UserRole.ADMIN, UserRole.MANAGER, UserRole.ANALYST] },
    { id: 'leads', label: 'Leads (GHL)', icon: 'fa-users-viewfinder', roles: [UserRole.ADMIN, UserRole.MANAGER] },
    { id: 'team', label: 'Team Mgmt', icon: 'fa-user-shield', roles: [UserRole.ADMIN] },
  ];

  const visibleItems = menuItems.filter(item => item.roles.includes(role));

  return (
    <div className="w-20 md:w-64 bg-slate-900 text-white flex flex-col transition-all duration-300">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
          <i className="fas fa-layer-group text-xl"></i>
        </div>
        <h1 className="hidden md:block text-xl font-bold tracking-tight">Snewroof <span className="text-indigo-400">Ops</span></h1>
      </div>
      
      <nav className="flex-1 px-4 py-4 space-y-2">
        {visibleItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              activeTab === item.id 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <i className={`fas ${item.icon} w-6 text-center text-lg`}></i>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-slate-800/50 rounded-2xl p-4 hidden md:block">
          <p className="text-xs text-slate-500 mb-1 uppercase font-semibold tracking-wider">System Status</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-sm font-medium">99.9% Uptime</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
