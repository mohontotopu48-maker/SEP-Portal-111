
import React from 'react';
import { User, UserRole } from '../types';

interface HeaderProps {
  currentUser: User;
  users: User[];
  onRoleChange: (userId: string) => void;
}

const Header: React.FC<HeaderProps> = ({ currentUser, users, onRoleChange }) => {
  return (
    <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex items-center gap-4">
        <div className="md:hidden">
          {/* Mobile menu toggle would go here */}
        </div>
        <div className="text-sm text-slate-500 font-medium">
          Portal v1.0 <span className="mx-2 text-slate-300">|</span> <span className="text-slate-400">Internal Environment</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex flex-col items-end hidden sm:flex">
          <span className="text-sm font-bold text-slate-800">{currentUser.fullName}</span>
          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
            currentUser.role === UserRole.ADMIN ? 'bg-red-100 text-red-600' :
            currentUser.role === UserRole.MANAGER ? 'bg-blue-100 text-blue-600' :
            'bg-slate-100 text-slate-600'
          }`}>
            {currentUser.role}
          </span>
        </div>

        <select 
          className="bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold px-2 py-1 outline-none focus:ring-2 focus:ring-indigo-500"
          value={currentUser.id}
          onChange={(e) => onRoleChange(e.target.value)}
        >
          {users.map(u => (
            <option key={u.id} value={u.id}>Switch to {u.fullName} ({u.role})</option>
          ))}
        </select>

        <div className="relative">
          <button className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors">
            <i className="fas fa-bell"></i>
          </button>
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 border-2 border-white rounded-full"></span>
        </div>
      </div>
    </header>
  );
};

export default Header;
