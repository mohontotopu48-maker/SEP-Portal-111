
import { UserRole, CostFrequency, Tool, ToolSecret, Cost, Monitor, Lead, Task, User } from './types';

export const MOCK_USERS: User[] = [
  { id: 'u1', email: 'admin@snewroof.com', fullName: 'Topon Admin', role: UserRole.ADMIN, isActive: true },
  { id: 'u2', email: 'manager@snewroof.com', fullName: 'Jane Manager', role: UserRole.MANAGER, isActive: true },
  { id: 'u3', email: 'analyst@snewroof.com', fullName: 'Bob Analyst', role: UserRole.ANALYST, isActive: true }
];

export const MOCK_TOOLS: Tool[] = [
  { id: 't1', name: 'GoHighLevel', url: 'https://gohighlevel.com', description: 'Primary CRM for lead generation', ownerId: 'u1', status: 'active', category: 'Marketing', createdAt: '2023-01-15' },
  { id: 't2', name: 'AWS', url: 'https://aws.amazon.com', description: 'Infrastructure and hosting', ownerId: 'u1', status: 'active', category: 'Infrastructure', createdAt: '2023-01-10' },
  { id: 't3', name: 'DigitalOcean', url: 'https://digitalocean.com', description: 'VPS and Managed Databases', ownerId: 'u2', status: 'active', category: 'Infrastructure', createdAt: '2023-05-20' }
];

export const MOCK_SECRETS: ToolSecret[] = [
  { id: 's1', toolId: 't1', keyName: 'API V2 Key', maskedValue: 'sk_live_....a1b2', expiryDate: '2025-12-31' },
  { id: 's2', toolId: 't2', keyName: 'Access Key ID', maskedValue: 'AKIA....XY34' }
];

export const MOCK_COSTS: Cost[] = [
  { id: 'c1', toolId: 't1', description: 'GHL Pro Plan', amount: 497.00, currency: 'USD', frequency: CostFrequency.MONTHLY, billingDate: '2023-10-01', nextRenewalDate: '2024-11-01', isActive: true },
  { id: 'c2', toolId: 't2', description: 'S3 Storage & EC2', amount: 1200.00, currency: 'USD', frequency: CostFrequency.YEARLY, billingDate: '2023-01-01', nextRenewalDate: '2024-01-01', isActive: true },
  { id: 'c3', description: 'Office Rent', amount: 2500.00, currency: 'USD', frequency: CostFrequency.MONTHLY, billingDate: '2023-10-01', isActive: true }
];

export const MOCK_MONITORS: Monitor[] = [
  { id: 'm1', name: 'Snewroof Main Site', url: 'https://snewroof.com', status: 'up', responseTimeMs: 145, lastChecked: new Date().toISOString(), sslExpiryDays: 45 },
  { id: 'm2', name: 'Portal App', url: 'https://app.snewroof.com', status: 'up', responseTimeMs: 82, lastChecked: new Date().toISOString(), sslExpiryDays: 12 },
  { id: 'm3', name: 'GHL Webhook Listener', url: 'https://api.snewroof.com/v1/webhooks', status: 'down', responseTimeMs: 0, lastChecked: new Date().toISOString(), sslExpiryDays: 180 }
];

export const MOCK_LEADS: Lead[] = [
  { id: 'l1', ghlContactId: 'ghl_123', firstName: 'John', email: 'john@example.com', attributionSource: 'FB Ads', status: 'New', createdAt: new Date().toISOString() },
  { id: 'l2', ghlContactId: 'ghl_456', firstName: 'Sarah', email: 'sarah@test.com', attributionSource: 'Google Search', status: 'Follow Up', createdAt: new Date().toISOString() }
];

export const MOCK_TASKS: Task[] = [
  { id: 'ts1', title: 'Fix SSL Certificate for Portal', dueDate: '2023-10-25', status: 'pending', priority: 'high' },
  { id: 'ts2', title: 'Audit GHL Subscriptions', dueDate: '2023-10-20', status: 'pending', priority: 'medium' },
  { id: 'ts3', title: 'Monthly Budget Review', dueDate: '2023-10-30', status: 'pending', priority: 'low' }
];
