
import React, { useState, useEffect, useMemo } from 'react';
import { 
  MOCK_USERS, 
  MOCK_TOOLS, 
  MOCK_COSTS, 
  MOCK_MONITORS, 
  MOCK_LEADS, 
  MOCK_TASKS, 
  MOCK_SECRETS 
} from './mockData';
import { UserRole, CostFrequency, User, SecretAuditLog, Tool, Cost, Monitor, Lead, Task, ToolSecret } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardView from './views/DashboardView';
import CostsView from './views/CostsView';
import ToolsView from './views/ToolsView';
import MonitorView from './views/MonitorView';
import LeadsView from './views/LeadsView';
import TeamView from './views/TeamView';

const STORAGE_KEY = 'snewroof_ops_data_v1';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User>(MOCK_USERS[0]);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // App State
  const [tools, setTools] = useState<Tool[]>([]);
  const [costs, setCosts] = useState<Cost[]>([]);
  const [monitors, setMonitors] = useState<Monitor[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [secrets, setSecrets] = useState<ToolSecret[]>([]);
  const [auditLogs, setAuditLogs] = useState<SecretAuditLog[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initialize Data from LocalStorage or Mock
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setTools(data.tools || MOCK_TOOLS);
        setCosts(data.costs || MOCK_COSTS);
        setMonitors(data.monitors || MOCK_MONITORS);
        setLeads(data.leads || MOCK_LEADS);
        setTasks(data.tasks || MOCK_TASKS);
        setSecrets(data.secrets || MOCK_SECRETS);
        setAuditLogs(data.auditLogs || []);
      } catch (e) {
        console.error("Failed to parse local storage data", e);
        loadMocks();
      }
    } else {
      loadMocks();
    }
    setIsLoaded(true);
  }, []);

  const loadMocks = () => {
    setTools(MOCK_TOOLS);
    setCosts(MOCK_COSTS);
    setMonitors(MOCK_MONITORS);
    setLeads(MOCK_LEADS);
    setTasks(MOCK_TASKS);
    setSecrets(MOCK_SECRETS);
  };

  // Persist State Changes
  useEffect(() => {
    if (isLoaded) {
      const data = { tools, costs, monitors, leads, tasks, secrets, auditLogs };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, [tools, costs, monitors, leads, tasks, secrets, auditLogs, isLoaded]);

  // Computed Values
  const monthlyBurnRate = useMemo(() => {
    return costs.reduce((acc, cost) => {
      if (!cost.isActive) return acc;
      if (cost.frequency === CostFrequency.MONTHLY) return acc + cost.amount;
      if (cost.frequency === CostFrequency.YEARLY) return acc + (cost.amount / 12);
      return acc;
    }, 0);
  }, [costs]);

  const renderActiveView = () => {
    if (!isLoaded) return <div className="flex items-center justify-center h-full text-slate-400">Loading Environment...</div>;

    switch (activeTab) {
      case 'dashboard':
        return <DashboardView 
          burnRate={monthlyBurnRate} 
          toolsCount={tools.length}
          monitors={monitors}
          tasks={tasks}
          setTasks={setTasks}
          leads={leads}
        />;
      case 'costs':
        return <CostsView costs={costs} setCosts={setCosts} role={currentUser.role} tools={tools} />;
      case 'tools':
        return <ToolsView 
          tools={tools} 
          setTools={setTools} 
          secrets={secrets} 
          setSecrets={setSecrets} 
          role={currentUser.role} 
          currentUser={currentUser}
          auditLogs={auditLogs}
          setAuditLogs={setAuditLogs}
        />;
      case 'monitoring':
        return <MonitorView monitors={monitors} setMonitors={setMonitors} role={currentUser.role} />;
      case 'leads':
        return <LeadsView leads={leads} setLeads={setLeads} />;
      case 'team':
        return <TeamView users={MOCK_USERS} role={currentUser.role} />;
      default:
        return <DashboardView 
          burnRate={monthlyBurnRate} 
          toolsCount={tools.length} 
          monitors={monitors} 
          tasks={tasks} 
          setTasks={setTasks}
          leads={leads} 
        />;
    }
  };

  const handleRoleChange = (userId: string) => {
    const user = MOCK_USERS.find(u => u.id === userId);
    if (user) setCurrentUser(user);
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans antialiased">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        role={currentUser.role} 
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          currentUser={currentUser} 
          users={MOCK_USERS} 
          onRoleChange={handleRoleChange} 
        />
        <main className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
          <div className="max-w-7xl mx-auto space-y-6">
            {renderActiveView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
