
import React, { useState } from 'react';
import { User, UserRole } from '../types';

interface TeamViewProps {
  users: User[];
  role: UserRole;
}

const TeamView: React.FC<TeamViewProps> = ({ users, role }) => {
  const [activeUsers, setActiveUsers] = useState<User[]>(users);

  if (role !== UserRole.ADMIN) {
    return (
      <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 shadow-sm animate-in zoom-in-95">
        <div className="w-16 h-16 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-lock text-2xl"></i>
        </div>
        <h3 className="text-xl font-bold text-slate-800">Access Restricted</h3>
        <p className="text-slate-500 max-w-sm mx-auto">You must have Admin privileges to manage team roles and platform governance.</p>
      </div>
    );
  }

  const deleteMember = (id: string) => {
    if (confirm("Revoke all access for this team member? This action is logged.")) {
      setActiveUsers(prev => prev.filter(u => u.id !== id));
    }
  };

  const toggleUserStatus = (id: string) => {
    setActiveUsers(prev => prev.map(u => u.id === id ? { ...u, isActive: !u.isActive } : u));
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Team Governance & RBAC</h2>
          <p className="text-slate-500">Manage internal access levels and security permissions</p>
        </div>
        <button className="bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-slate-900/20 hover:bg-slate-800 transition-colors">
          <i className="fas fa-user-plus"></i> Invite Member
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeUsers.map(user => (
          <div key={user.id} className={`bg-white p-6 rounded-2xl border transition-all shadow-sm relative overflow-hidden ${user.isActive ? 'border-slate-200' : 'border-red-200 opacity-75'}`}>
            <div className="flex items-center gap-4 mb-6">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl shadow-lg ${
                user.role === UserRole.ADMIN ? 'bg-red-500 shadow-red-500/20' : 
                user.role === UserRole.MANAGER ? 'bg-indigo-500 shadow-indigo-500/20' : 'bg-slate-500 shadow-slate-500/20'
              }`}>
                <i className={`fas ${user.role === UserRole.ADMIN ? 'fa-crown' : 'fa-user-shield'}`}></i>
              </div>
              <div>
                <h3 className="font-bold text-slate-800">{user.fullName}</h3>
                <p className="text-xs text-slate-400">{user.email}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium uppercase tracking-widest text-[9px]">Platform Role</span>
                <span className={`px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px] ${
                  user.role === UserRole.ADMIN ? 'bg-red-50 text-red-600' : 
                  user.role === UserRole.MANAGER ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-50 text-slate-600'
                }`}>
                  {user.role}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium uppercase tracking-widest text-[9px]">Account Status</span>
                <button 
                  onClick={() => toggleUserStatus(user.id)}
                  className={`font-bold transition-colors ${user.isActive ? 'text-emerald-600' : 'text-red-500'}`}
                >
                  {user.isActive ? 'Active' : 'Suspended'}
                </button>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100 flex gap-2">
              <button className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 py-2 rounded-lg text-xs font-bold transition-colors">
                Audit Trail
              </button>
              <button 
                onClick={() => deleteMember(user.id)}
                className="w-10 h-10 bg-slate-50 hover:bg-red-50 hover:text-red-500 text-slate-400 rounded-lg flex items-center justify-center transition-colors"
              >
                <i className="fas fa-trash-alt"></i>
              </button>
            </div>
            
            {!user.isActive && (
              <div className="absolute top-0 right-0 p-2">
                <span className="bg-red-500 text-white text-[8px] font-black uppercase px-2 py-1 rounded-bl-xl rounded-tr-xl">LOCKED</span>
              </div>
            )}
          </div>
        ))}
      </div>
      
      <div className="bg-amber-50 border border-amber-200 p-6 rounded-2xl flex items-start gap-4">
        <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center shrink-0">
          <i className="fas fa-shield-halved"></i>
        </div>
        <div>
          <h4 className="font-bold text-amber-900 text-sm">Security Policy Reminder</h4>
          <p className="text-xs text-amber-800/80 leading-relaxed mt-1">
            Role assignments define access to tool secrets and financial data. Always ensure the 'Manager' role is restricted to designated personnel. Audits are performed every 24 hours.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TeamView;
