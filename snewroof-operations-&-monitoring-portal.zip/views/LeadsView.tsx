
import React, { useState, useMemo } from 'react';
import { Lead } from '../types';

interface LeadsViewProps {
  leads: Lead[];
  setLeads: React.Dispatch<React.SetStateAction<Lead[]>>;
}

const LeadsView: React.FC<LeadsViewProps> = ({ leads, setLeads }) => {
  const [search, setSearch] = useState('');

  const filteredLeads = useMemo(() => {
    return leads.filter(l => 
      l.firstName.toLowerCase().includes(search.toLowerCase()) || 
      l.email.toLowerCase().includes(search.toLowerCase()) ||
      l.attributionSource.toLowerCase().includes(search.toLowerCase())
    );
  }, [leads, search]);

  const updateStatus = (id: string, newStatus: string) => {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status: newStatus } : l));
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
      <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Lead Synchronization (GHL)</h2>
          <p className="text-sm text-slate-500">Real-time ingestion from GoHighLevel Webhooks</p>
        </div>
        <div className="flex items-center gap-3">
           <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-100 text-xs font-bold">
             <i className="fas fa-link animate-pulse"></i> Webhook Listening
           </div>
           <button className="bg-slate-50 text-slate-600 px-4 py-2 rounded-xl text-sm font-bold hover:bg-slate-100 transition-colors">
            <i className="fas fa-download mr-2"></i> Export CSV
          </button>
        </div>
      </div>

      <div className="p-4 border-b border-slate-100">
        <div className="relative max-w-sm">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
          <input 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
            placeholder="Search leads by name or email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Contact</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Source</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">GHL ID</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Created</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredLeads.length > 0 ? filteredLeads.map((lead) => (
              <tr key={lead.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-xs font-bold">
                      {lead.firstName.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">{lead.firstName}</p>
                      <p className="text-xs text-slate-400">{lead.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm text-slate-600">{lead.attributionSource}</span>
                </td>
                <td className="px-6 py-4">
                  <code className="text-[11px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">{lead.ghlContactId}</code>
                </td>
                <td className="px-6 py-4">
                   <select 
                    className="bg-transparent border-none outline-none text-[10px] font-bold uppercase tracking-wider text-blue-600 cursor-pointer"
                    value={lead.status}
                    onChange={(e) => updateStatus(lead.id, e.target.value)}
                   >
                     <option value="New">New</option>
                     <option value="Follow Up">Follow Up</option>
                     <option value="Converted">Converted</option>
                     <option value="Lost">Lost</option>
                   </select>
                </td>
                <td className="px-6 py-4 text-right">
                  <p className="text-xs text-slate-500">{new Date(lead.createdAt).toLocaleDateString()}</p>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">No leads found matching your search.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeadsView;
