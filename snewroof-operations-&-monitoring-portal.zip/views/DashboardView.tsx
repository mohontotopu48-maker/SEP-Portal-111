
import React, { useState } from 'react';
import { Monitor, Task, Lead } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardViewProps {
  burnRate: number;
  toolsCount: number;
  monitors: Monitor[];
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  leads: Lead[];
}

const DashboardView: React.FC<DashboardViewProps> = ({ burnRate, toolsCount, monitors, tasks, setTasks, leads }) => {
  const onlineMonitors = monitors.filter(m => m.status === 'up').length;
  const newLeads = leads.length;

  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  // Mock historical data for chart
  const data = [
    { name: 'May', cost: 3200 },
    { name: 'Jun', cost: 3500 },
    { name: 'Jul', cost: 4100 },
    { name: 'Aug', cost: 3800 },
    { name: 'Sep', cost: 4200 },
    { name: 'Oct', cost: Math.round(burnRate) },
  ];

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (index: number) => {
    if (draggedIndex === null) return;
    
    const updatedTasks = [...tasks];
    const [movedItem] = updatedTasks.splice(draggedIndex, 1);
    updatedTasks.splice(index, 0, movedItem);
    
    setTasks(updatedTasks);
    setDraggedIndex(null);
  };

  const toggleTaskStatus = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        return { ...t, status: t.status === 'done' ? 'pending' : 'done' };
      }
      return t;
    }));
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'text-red-500 bg-red-50 border-red-100';
      case 'medium': return 'text-amber-500 bg-amber-50 border-amber-100';
      case 'low': return 'text-emerald-500 bg-emerald-50 border-emerald-100';
      default: return 'text-slate-500 bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Monthly Burn Rate" 
          value={`$${burnRate.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} 
          icon="fa-fire-flame-curved" 
          color="bg-orange-500" 
          trend="+12% from last month"
        />
        <StatCard 
          title="Website Health" 
          value={`${onlineMonitors}/${monitors.length} Up`} 
          icon="fa-globe" 
          color="bg-emerald-500"
          subtext="99.9% Overall availability"
        />
        <StatCard 
          title="Active Tools" 
          value={toolsCount.toString()} 
          icon="fa-puzzle-piece" 
          color="bg-indigo-500" 
          subtext="Integrated ecosystems"
        />
        <StatCard 
          title="New Leads (24h)" 
          value={newLeads.toString()} 
          icon="fa-bullseye" 
          color="bg-blue-500" 
          subtext="Synced from GHL"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-slate-800">Operational Cost Trend</h3>
              <p className="text-xs text-slate-400">Infrastructure and overhead tracking</p>
            </div>
            <div className="flex items-center gap-2">
               <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">
                 <i className="fas fa-arrow-up"></i> 4.5%
               </span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} dy={10} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                  formatter={(value: any) => [`$${value}`, 'Cost']}
                />
                <Area type="monotone" dataKey="cost" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorCost)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col h-full max-h-[500px]">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800">Action Items</h3>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Reorder Priority</span>
          </div>
          
          <div className="space-y-4 flex-1 overflow-y-auto pr-2 scrollbar-hide">
            {monitors.some(m => m.status === 'down') && (
              <div className="flex items-start gap-4 p-4 bg-red-50 rounded-xl border border-red-100 animate-pulse">
                <div className="p-2 bg-red-500 rounded-lg text-white">
                  <i className="fas fa-plug-circle-xmark"></i>
                </div>
                <div>
                  <p className="text-sm font-bold text-red-700">Endpoint Critical Failure</p>
                  <p className="text-xs text-red-600">Site monitoring reporting offline</p>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {tasks.length > 0 ? tasks.map((task, index) => (
                <div 
                  key={task.id}
                  draggable
                  onDragStart={() => handleDragStart(index)}
                  onDragOver={handleDragOver}
                  onDrop={() => handleDrop(index)}
                  className={`group relative flex items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 transition-all cursor-grab active:cursor-grabbing hover:border-indigo-300 hover:shadow-sm ${
                    draggedIndex === index ? 'opacity-40 scale-95 border-dashed border-indigo-400' : 'opacity-100'
                  }`}
                >
                  <div className="text-slate-300 group-hover:text-indigo-400 transition-colors">
                    <i className="fas fa-grip-vertical"></i>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-md border ${getPriorityColor(task.priority)}`}>
                        {task.priority}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">{new Date(task.dueDate).toLocaleDateString()}</span>
                    </div>
                    <p className={`text-sm font-bold truncate ${task.status === 'done' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{task.title}</p>
                  </div>

                  <button 
                    onClick={() => toggleTaskStatus(task.id)}
                    className={`w-5 h-5 rounded-full border-2 transition-colors flex items-center justify-center ${
                      task.status === 'done' ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 hover:border-indigo-500'
                    }`}
                  >
                    {task.status === 'done' && <i className="fas fa-check text-[10px]"></i>}
                  </button>
                </div>
              )) : (
                <div className="text-center py-12 text-slate-400 italic text-sm">No active tasks</div>
              )}
            </div>

            <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <div className="p-2 bg-blue-500 rounded-lg text-white">
                <i className="fas fa-rotate"></i>
              </div>
              <div>
                <p className="text-sm font-bold text-blue-700">GHL Sync Active</p>
                <p className="text-xs text-blue-600">Synced with {leads.length} contacts</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string; icon: string; color: string; trend?: string; subtext?: string }> = ({ 
  title, value, icon, color, trend, subtext 
}) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-4">
      <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center text-white text-xl shadow-lg`}>
        <i className={`fas ${icon}`}></i>
      </div>
      {trend && <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">{trend}</span>}
    </div>
    <p className="text-slate-500 text-sm font-medium">{title}</p>
    <h2 className="text-2xl font-bold text-slate-800 mt-1">{value}</h2>
    {subtext && <p className="text-xs text-slate-400 mt-1">{subtext}</p>}
  </div>
);

export default DashboardView;
