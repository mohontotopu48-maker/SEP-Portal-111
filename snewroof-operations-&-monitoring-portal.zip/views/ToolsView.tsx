
import React, { useState, useMemo } from 'react';
import { Tool, ToolSecret, UserRole, SecretAuditLog, User } from '../types';

interface ToolsViewProps {
  tools: Tool[];
  setTools: React.Dispatch<React.SetStateAction<Tool[]>>;
  secrets: ToolSecret[];
  setSecrets: React.Dispatch<React.SetStateAction<ToolSecret[]>>;
  role: UserRole;
  currentUser: User;
  auditLogs: SecretAuditLog[];
  setAuditLogs: React.Dispatch<React.SetStateAction<SecretAuditLog[]>>;
}

const CATEGORIES = ['All', 'Infrastructure', 'Marketing', 'Development', 'Operations', 'Finance'];

const ToolsView: React.FC<ToolsViewProps> = ({ 
  tools, 
  setTools, 
  secrets, 
  setSecrets, 
  role, 
  currentUser,
  auditLogs,
  setAuditLogs
}) => {
  const isAdmin = role === UserRole.ADMIN;
  const canManage = isAdmin || role === UserRole.MANAGER;

  const [addingSecretTo, setAddingSecretTo] = useState<string | null>(null);
  const [newSecretName, setNewSecretName] = useState('');
  const [newSecretValue, setNewSecretValue] = useState('');
  const [revealedSecrets, setRevealedSecrets] = useState<Set<string>>(new Set());
  const [showLogs, setShowLogs] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // State for Modals
  const [secretToRevoke, setSecretToRevoke] = useState<ToolSecret | null>(null);
  const [isAddingTool, setIsAddingTool] = useState(false);
  const [newTool, setNewTool] = useState({ name: '', url: '', description: '', category: 'Development' });

  const filteredTools = useMemo(() => {
    return tools.filter(tool => {
      const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
      const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            tool.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [tools, selectedCategory, searchQuery]);

  const addAuditEntry = (action: SecretAuditLog['action'], toolId: string, secretKeyName: string) => {
    const tool = tools.find(t => t.id === toolId);
    const newEntry: SecretAuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      action,
      toolId,
      toolName: tool?.name || 'Unknown Tool',
      secretKeyName,
    };
    setAuditLogs(prev => [newEntry, ...prev]);
  };

  const handleCreateTool = () => {
    if (!newTool.name || !newTool.url) return;
    const tool: Tool = {
      id: `t-${Date.now()}`,
      ...newTool,
      ownerId: currentUser.id,
      status: 'active',
      createdAt: new Date().toISOString()
    };
    setTools(prev => [...prev, tool]);
    setIsAddingTool(false);
    setNewTool({ name: '', url: '', description: '', category: 'Development' });
  };

  const handleDeleteTool = (id: string) => {
    if (window.confirm("Are you sure you want to delete this tool? All associated secrets and costs will remain orphaned.")) {
      setTools(prev => prev.filter(t => t.id !== id));
    }
  };

  const toggleReveal = (id: string, toolId: string, keyName: string) => {
    const newRevealed = new Set(revealedSecrets);
    if (newRevealed.has(id)) {
      newRevealed.delete(id);
    } else {
      newRevealed.add(id);
      addAuditEntry('Secret Viewed', toolId, keyName);
    }
    setRevealedSecrets(newRevealed);
  };

  const handleAddSecret = (toolId: string) => {
    if (!newSecretName || !newSecretValue) return;

    const masked = newSecretValue.length > 8 
      ? `${newSecretValue.substring(0, 4)}....${newSecretValue.substring(newSecretValue.length - 4)}`
      : '********';

    const newSecret: ToolSecret = {
      id: `s-${Math.random().toString(36).substr(2, 9)}`,
      toolId,
      keyName: newSecretName,
      maskedValue: masked,
    };

    setSecrets([...secrets, newSecret]);
    addAuditEntry('Secret Added', toolId, newSecretName);
    
    setAddingSecretTo(null);
    setNewSecretName('');
    setNewSecretValue('');
  };

  const confirmRevokeSecret = () => {
    if (secretToRevoke) {
      setSecrets(secrets.filter(s => s.id !== secretToRevoke.id));
      addAuditEntry('Secret Revoked', secretToRevoke.toolId, secretToRevoke.keyName);
      setSecretToRevoke(null);
    }
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Infrastructure': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Marketing': return 'bg-pink-100 text-pink-700 border-pink-200';
      case 'Development': return 'bg-cyan-100 text-cyan-700 border-cyan-200';
      case 'Operations': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Finance': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      {/* New Asset Modal */}
      {isAddingTool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-900">Add New Software Asset</h3>
              <button onClick={() => setIsAddingTool(false)} className="text-slate-400 hover:text-slate-600">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Asset Name</label>
                  <input 
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Slack"
                    value={newTool.name}
                    onChange={e => setNewTool({...newTool, name: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Category</label>
                  <select 
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                    value={newTool.category}
                    onChange={e => setNewTool({...newTool, category: e.target.value})}
                  >
                    {CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Asset URL</label>
                <input 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="https://..."
                  value={newTool.url}
                  onChange={e => setNewTool({...newTool, url: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Description</label>
                <textarea 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 h-24 resize-none"
                  placeholder="What is this tool used for?"
                  value={newTool.description}
                  onChange={e => setNewTool({...newTool, description: e.target.value})}
                />
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex gap-3">
              <button onClick={() => setIsAddingTool(false)} className="flex-1 px-4 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-100 transition-colors">Cancel</button>
              <button onClick={handleCreateTool} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-500/30 transition-all">Create Asset</button>
            </div>
          </div>
        </div>
      )}

      {/* Revoke Confirmation Modal */}
      {secretToRevoke && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-200 border border-slate-200">
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-triangle-exclamation text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Revoke Secret?</h3>
              <p className="text-slate-500 mb-6 leading-relaxed text-sm">
                You are about to revoke <span className="font-bold text-slate-800">"{secretToRevoke.keyName}"</span>. 
                Systems relying on this credential will lose access immediately. This action is logged and irreversible.
              </p>
              <div className="flex gap-3">
                <button onClick={() => setSecretToRevoke(null)} className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors">Cancel</button>
                <button onClick={confirmRevokeSecret} className="flex-1 px-4 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-500/30">Revoke Now</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Software Assets & APIs</h2>
          <p className="text-slate-500">Centralized secret management and tool lifecycle</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setShowLogs(!showLogs)}
            className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              showLogs ? 'bg-indigo-100 text-indigo-700' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <i className="fas fa-history"></i> {showLogs ? 'Hide Audit Logs' : 'View Audit Logs'}
          </button>
          {canManage && (
            <button 
              onClick={() => setIsAddingTool(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-colors"
            >
              <i className="fas fa-plus"></i> New Asset
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input 
            type="text" 
            placeholder="Search tools by name or description..." 
            className="w-full pl-11 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm shadow-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              <i className="fas fa-times-circle"></i>
            </button>
          )}
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-xs font-bold border transition-all ${
                selectedCategory === cat 
                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' 
                  : 'bg-white border-slate-200 text-slate-500 hover:border-indigo-300 hover:text-indigo-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {showLogs && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden animate-in slide-in-from-top-4 duration-300">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <i className="fas fa-shield-halved text-indigo-500"></i>
              Secret Governance Audit Logs
            </h3>
            <button onClick={() => setShowLogs(false)} className="text-slate-400 hover:text-slate-600">
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="max-h-[400px] overflow-y-auto">
            {auditLogs.length > 0 ? (
              <table className="w-full text-left text-sm">
                <thead className="sticky top-0 bg-slate-50 border-b border-slate-100 shadow-sm z-10">
                  <tr>
                    <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-widest text-[10px]">Timestamp</th>
                    <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-widest text-[10px]">User</th>
                    <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-widest text-[10px]">Action</th>
                    <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-widest text-[10px]">Resource</th>
                    <th className="px-6 py-3 font-bold text-slate-500 uppercase tracking-widest text-[10px]">Key Name</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {auditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-3 text-slate-500 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                      <td className="px-6 py-3 font-semibold text-slate-800">{log.userName}</td>
                      <td className="px-6 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          log.action === 'Secret Added' ? 'bg-emerald-100 text-emerald-700' :
                          log.action === 'Secret Viewed' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-slate-600 font-medium">{log.toolName}</td>
                      <td className="px-6 py-3 text-slate-400 font-mono text-[11px]">{log.secretKeyName}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="p-12 text-center text-slate-400 italic">No governance events logged yet.</div>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTools.map((tool) => {
          const toolSecrets = secrets.filter(s => s.toolId === tool.id);
          return (
            <div key={tool.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col hover:border-indigo-300 hover:shadow-lg transition-all group/card">
              <div className="p-6 border-b border-slate-100">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 text-xl border border-slate-100 group-hover/card:bg-indigo-50 group-hover/card:text-indigo-500 transition-colors">
                    <i className="fas fa-cube"></i>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-lg ${
                      tool.status === 'active' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {tool.status}
                    </span>
                    <span className={`text-[9px] font-bold uppercase border px-1.5 py-0.5 rounded-md ${getCategoryColor(tool.category)}`}>
                      {tool.category}
                    </span>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-slate-800">{tool.name}</h3>
                <a href={tool.url} target="_blank" rel="noreferrer" className="text-xs text-indigo-500 hover:underline mb-2 block truncate">{tool.url}</a>
                <p className="text-sm text-slate-500 line-clamp-2 min-h-[40px]">{tool.description}</p>
              </div>

              <div className="p-4 bg-slate-50/50 flex-1 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Stored Secrets</p>
                  {canManage && (
                    <button onClick={() => setAddingSecretTo(tool.id)} className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                      <i className="fas fa-plus-circle"></i> Add New
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  {addingSecretTo === tool.id && (
                    <div className="bg-white p-3 rounded-xl border-2 border-indigo-200 animate-in zoom-in-95 duration-200 shadow-lg">
                      <div className="space-y-2">
                        <input type="text" placeholder="Key Name" className="w-full text-xs p-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" value={newSecretName} onChange={(e) => setNewSecretName(e.target.value)} />
                        <input type="password" placeholder="Secret Value" className="w-full text-xs p-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" value={newSecretValue} onChange={(e) => setNewSecretValue(e.target.value)} />
                        <div className="flex gap-2">
                          <button onClick={() => handleAddSecret(tool.id)} className="flex-1 bg-indigo-600 text-white text-[10px] font-bold py-2 rounded-lg hover:bg-indigo-700">Save</button>
                          <button onClick={() => setAddingSecretTo(null)} className="flex-1 bg-slate-100 text-slate-600 text-[10px] font-bold py-2 rounded-lg hover:bg-slate-200">Cancel</button>
                        </div>
                      </div>
                    </div>
                  )}

                  {toolSecrets.length > 0 ? toolSecrets.map(secret => (
                    <div key={secret.id} className="bg-white p-3 rounded-xl border border-slate-100 flex items-center justify-between group/secret hover:border-indigo-200 transition-colors shadow-sm">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-700">{secret.keyName}</span>
                        <code className="text-[10px] text-indigo-600 font-mono">{revealedSecrets.has(secret.id) ? 'sk_live_v2_f83h2d9j12...' : secret.maskedValue}</code>
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => toggleReveal(secret.id, tool.id, secret.keyName)} className={`p-1.5 rounded-lg ${revealedSecrets.has(secret.id) ? 'bg-indigo-50 text-indigo-600' : 'text-slate-300 hover:text-indigo-500'}`}><i className={`fas ${revealedSecrets.has(secret.id) ? 'fa-eye' : 'fa-eye-slash'}`}></i></button>
                        {canManage && <button onClick={() => setSecretToRevoke(secret)} className="text-slate-300 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50"><i className="fas fa-trash-alt"></i></button>}
                      </div>
                    </div>
                  )) : !addingSecretTo && <div className="text-center py-4 border-2 border-dashed border-slate-200 rounded-xl text-[10px] text-slate-400 italic">No credentials stored</div>}
                </div>
              </div>

              <div className="px-6 py-4 flex items-center justify-between bg-white border-t border-slate-100">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1"><i className="fas fa-user-circle"></i> Owner: {tool.ownerId}</span>
                  <span className="text-[10px] text-slate-400 flex items-center gap-1"><i className="fas fa-calendar-alt"></i> Added: {new Date(tool.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="flex gap-2">
                  {isAdmin && <button onClick={() => handleDeleteTool(tool.id)} className="w-8 h-8 rounded-lg bg-slate-50 text-slate-400 hover:text-red-600 hover:bg-red-50 flex items-center justify-center transition-colors"><i className="fas fa-trash-alt"></i></button>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ToolsView;
