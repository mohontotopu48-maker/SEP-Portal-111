
import React, { useState } from 'react';
import { Cost, UserRole, Tool, CostFrequency } from '../types';

interface CostsViewProps {
  costs: Cost[];
  setCosts: React.Dispatch<React.SetStateAction<Cost[]>>;
  role: UserRole;
  tools: Tool[];
}

const CostsView: React.FC<CostsViewProps> = ({ costs, setCosts, role, tools }) => {
  const isAdmin = role === UserRole.ADMIN;
  const isManager = role === UserRole.MANAGER;
  const canEdit = isAdmin || isManager;

  const [isAdding, setIsAdding] = useState(false);
  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: 0,
    frequency: CostFrequency.MONTHLY,
    toolId: '',
    billingDate: new Date().toISOString().split('T')[0]
  });

  const handleAddExpense = () => {
    if (!newExpense.description || newExpense.amount <= 0) return;
    const cost: Cost = {
      id: `c-${Date.now()}`,
      ...newExpense,
      currency: 'USD',
      isActive: true,
      nextRenewalDate: newExpense.frequency !== CostFrequency.ONE_TIME ? '2025-01-01' : undefined
    };
    setCosts(prev => [...prev, cost]);
    setIsAdding(false);
    setNewExpense({ description: '', amount: 0, frequency: CostFrequency.MONTHLY, toolId: '', billingDate: new Date().toISOString().split('T')[0] });
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
      {/* Add Expense Modal */}
      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">Add Expense</h3>
              <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600"><i className="fas fa-times"></i></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Description</label>
                <input className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newExpense.description} onChange={e => setNewExpense({...newExpense, description: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Amount ($)</label>
                  <input type="number" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newExpense.amount} onChange={e => setNewExpense({...newExpense, amount: Number(e.target.value)})} />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Frequency</label>
                  <select className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newExpense.frequency} onChange={e => setNewExpense({...newExpense, frequency: e.target.value as CostFrequency})}>
                    <option value={CostFrequency.MONTHLY}>Monthly</option>
                    <option value={CostFrequency.YEARLY}>Yearly</option>
                    <option value={CostFrequency.ONE_TIME}>One-Time</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Related Tool (Optional)</label>
                <select className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" value={newExpense.toolId} onChange={e => setNewExpense({...newExpense, toolId: e.target.value})}>
                  <option value="">General Overhead</option>
                  {tools.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex gap-3">
              <button onClick={() => setIsAdding(false)} className="flex-1 px-4 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold">Cancel</button>
              <button onClick={handleAddExpense} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/30">Add Cost</button>
            </div>
          </div>
        </div>
      )}

      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Billing & Expense Manager</h2>
          <p className="text-sm text-slate-500">Track and optimize operational burn rate</p>
        </div>
        {canEdit && (
          <button onClick={() => setIsAdding(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-500/10">
            <i className="fas fa-plus"></i> Add Expense
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Asset / Description</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Amount</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Frequency</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Next Billing</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {costs.map((cost) => (
              <tr key={cost.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-slate-100 rounded flex items-center justify-center text-slate-500">
                      <i className="fas fa-file-invoice-dollar"></i>
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">{cost.description}</p>
                      <p className="text-xs text-slate-400">{cost.toolId ? tools.find(t => t.id === cost.toolId)?.name : 'General Overhead'}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm font-bold text-slate-900">${cost.amount.toLocaleString()}</span>
                  <span className="text-xs text-slate-400 ml-1">{cost.currency}</span>
                </td>
                <td className="px-6 py-4">
                  <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full ${
                    cost.frequency === CostFrequency.MONTHLY ? 'bg-indigo-100 text-indigo-600' :
                    cost.frequency === CostFrequency.YEARLY ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {cost.frequency.replace('_', ' ')}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{cost.nextRenewalDate || 'N/A'}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    {canEdit && <button className="p-2 text-slate-400 hover:text-indigo-600"><i className="fas fa-edit"></i></button>}
                    {isAdmin && <button onClick={() => setCosts(prev => prev.filter(c => c.id !== cost.id))} className="p-2 text-slate-400 hover:text-red-600"><i className="fas fa-trash"></i></button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CostsView;
