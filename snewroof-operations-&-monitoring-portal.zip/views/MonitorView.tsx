
import React, { useState } from 'react';
import { Monitor, UserRole } from '../types';

interface MonitorViewProps {
  monitors: Monitor[];
  setMonitors: React.Dispatch<React.SetStateAction<Monitor[]>>;
  role: UserRole;
}

const MonitorView: React.FC<MonitorViewProps> = ({ monitors, setMonitors, role }) => {
  const isAdmin = role === UserRole.ADMIN;
  const [isAdding, setIsAdding] = useState(false);
  const [newMonitor, setNewMonitor] = useState({ name: '', url: '' });

  const handleCreateMonitor = () => {
    if (!newMonitor.name || !newMonitor.url) return;
    const monitor: Monitor = {
      id: `m-${Date.now()}`,
      name: newMonitor.name,
      url: newMonitor.url,
      status: 'checking',
      responseTimeMs: 0,
      lastChecked: new Date().toISOString(),
      sslExpiryDays: 90
    };
    setMonitors(prev => [...prev, monitor]);
    setIsAdding(false);
    setNewMonitor({ name: '', url: '' });
    
    // Simulate check
    setTimeout(() => {
      setMonitors(prev => prev.map(m => m.id === monitor.id ? {...m, status: 'up', responseTimeMs: 120} : m));
    }, 2000);
  };

  const handleDelete = (id: string) => {
    if (confirm("Stop monitoring this endpoint?")) {
      setMonitors(prev => prev.filter(m => m.id !== id));
    }
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
      {/* New Monitor Modal */}
      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">New Uptime Monitor</h3>
              <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600"><i className="fas fa-times"></i></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Friendly Name</label>
                <input className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g. Customer API" value={newMonitor.name} onChange={e => setNewMonitor({...newMonitor, name: e.target.value})} />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Endpoint URL</label>
                <input className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500" placeholder="https://..." value={newMonitor.url} onChange={e => setNewMonitor({...newMonitor, url: e.target.value})} />
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex gap-3">
              <button onClick={() => setIsAdding(false)} className="flex-1 px-4 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold">Cancel</button>
              <button onClick={handleCreateMonitor} className="flex-1 px-4 py-3 bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/30">Start Monitoring</button>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Uptime & Health Monitor</h2>
          <p className="text-slate-500">Autonomous polling engine (Every 5 minutes)</p>
        </div>
        {isAdmin && (
          <button onClick={() => setIsAdding(true)} className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-500/10">
            <i className="fas fa-plus"></i> New Monitor
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {monitors.map((monitor) => (
          <div key={monitor.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center gap-6 group hover:border-emerald-200 transition-all">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl shadow-lg ${
              monitor.status === 'up' ? 'bg-emerald-500 shadow-emerald-500/20' : 
              monitor.status === 'down' ? 'bg-red-500 shadow-red-500/20' : 'bg-slate-400'
            }`}>
              <i className={`fas ${monitor.status === 'up' ? 'fa-check' : monitor.status === 'checking' ? 'fa-sync fa-spin' : 'fa-triangle-exclamation'}`}></i>
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="font-bold text-slate-800 flex items-center justify-center md:justify-start gap-2">
                {monitor.name}
                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${monitor.status === 'up' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                  {monitor.status}
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-1">{monitor.url}</p>
            </div>
            <div className="grid grid-cols-3 gap-8 px-8 border-x border-slate-100 hidden md:grid">
              <div><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Latency</p><p className="text-sm font-bold text-slate-700">{monitor.status === 'checking' ? '--' : `${monitor.responseTimeMs}ms`}</p></div>
              <div><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">SSL Expiry</p><p className={`text-sm font-bold ${monitor.sslExpiryDays && monitor.sslExpiryDays < 14 ? 'text-red-500' : 'text-slate-700'}`}>{monitor.sslExpiryDays || '--'} days</p></div>
              <div><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Uptime</p><p className="text-sm font-bold text-emerald-500">99.98%</p></div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Last Check</p>
                <p className="text-[11px] text-slate-500">{new Date(monitor.lastChecked).toLocaleTimeString()}</p>
              </div>
              <button onClick={() => handleDelete(monitor.id)} className="w-10 h-10 rounded-xl bg-slate-50 text-slate-400 hover:bg-red-50 hover:text-red-600 flex items-center justify-center transition-colors"><i className="fas fa-trash-alt"></i></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MonitorView;
