
export enum UserRole {
  ADMIN = 'admin',
  MANAGER = 'manager',
  ANALYST = 'analyst'
}

export enum CostFrequency {
  MONTHLY = 'monthly',
  YEARLY = 'yearly',
  ONE_TIME = 'one_time'
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  isActive: boolean;
}

export interface Tool {
  id: string;
  name: string;
  url: string;
  description: string;
  ownerId: string;
  status: 'active' | 'deprecated' | 'trial';
  category: string;
  createdAt: string;
}

export interface ToolSecret {
  id: string;
  toolId: string;
  keyName: string;
  maskedValue: string; // Used for UI display
  expiryDate?: string;
}

export interface SecretAuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: 'Secret Added' | 'Secret Viewed' | 'Secret Revoked';
  toolId: string;
  toolName: string;
  secretKeyName: string;
}

export interface Cost {
  id: string;
  toolId?: string; // Nullable for general overhead
  description: string;
  amount: number;
  currency: string;
  frequency: CostFrequency;
  billingDate: string;
  nextRenewalDate?: string;
  isActive: boolean;
}

export interface Monitor {
  id: string;
  name: string;
  url: string;
  status: 'up' | 'down' | 'checking';
  responseTimeMs: number;
  lastChecked: string;
  sslExpiryDays?: number;
}

export interface Lead {
  id: string;
  ghlContactId: string;
  firstName: string;
  email: string;
  attributionSource: string;
  status: string;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  dueDate: string;
  status: 'pending' | 'in_progress' | 'done';
  priority: 'low' | 'medium' | 'high';
}
